#include <stdio.h>


printf("%d\n", 4);