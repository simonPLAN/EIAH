
printf("%s\n", "fdmlkj");