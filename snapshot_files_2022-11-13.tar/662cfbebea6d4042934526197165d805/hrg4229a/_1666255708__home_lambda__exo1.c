#include <stdio.h>

char[] test = "qmslkdfj";
printf("%s\n", test);