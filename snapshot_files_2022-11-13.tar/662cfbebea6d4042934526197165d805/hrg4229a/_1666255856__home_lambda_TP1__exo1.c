#include <stdio.h>

printf("qmdsfj");