#include <stdio.h>


printf("%s\n", "abcd");