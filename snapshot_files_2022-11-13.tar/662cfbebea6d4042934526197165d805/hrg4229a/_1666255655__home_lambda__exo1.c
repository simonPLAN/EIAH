#include <stdio.h>

printf("%s\n", "fdmlkj");