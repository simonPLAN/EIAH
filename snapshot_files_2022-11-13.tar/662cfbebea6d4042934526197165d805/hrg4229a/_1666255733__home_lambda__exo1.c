#include <stdio.h>

char test = 'd';