#include <stdio.h>
#include <string.h>

&rep = echo "pwd";
&listRep = echo "ls rep";
echo "listRep";