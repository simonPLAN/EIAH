int main()
{
    execl(./p2fils1.c)
}