/* Gestion des processus sous Linux */
/* TD - Exercice 2 */
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>

