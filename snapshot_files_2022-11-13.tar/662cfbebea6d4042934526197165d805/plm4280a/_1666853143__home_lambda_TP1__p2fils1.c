#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <wait.h>
#include <string.h>

voidTraitFils1();
void traitFils1() {
	printf("\n***fils1 --> PID= %d\n", getpid());
	exit(3);
}
