#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <wait.h>
#include <string.h>

void chercher(char * argv [], char *fileName);

int main (){

	
	FILE* fichier = NULL;
	fichier = fopen(test.txt, "r+");

	return 0;

}

