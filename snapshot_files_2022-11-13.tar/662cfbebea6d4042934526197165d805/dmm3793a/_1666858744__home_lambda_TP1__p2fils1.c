#include <stdio.h>

int main(){
    printf("\n****fils1 --> PID = %d\n",getpid());
    exit(3);
}