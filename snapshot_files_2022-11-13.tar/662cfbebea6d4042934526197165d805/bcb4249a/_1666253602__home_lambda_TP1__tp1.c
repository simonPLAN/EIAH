#include <stdio.h>
#include <time.h>
# include <sys/types.h>
# include <unistd.h>

int main(
    
    pid_t fork( void ) ;
    printf("%d", pid_t);

}
