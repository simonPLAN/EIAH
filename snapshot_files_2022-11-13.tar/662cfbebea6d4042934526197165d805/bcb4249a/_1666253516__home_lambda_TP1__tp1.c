#include <stdio.h>
#include <time.h>
# include <sys/types.h>
# include <unistd.h>

int main(int argc, char *argv[]) {

    
    pid_t fork( void ) ;

}
