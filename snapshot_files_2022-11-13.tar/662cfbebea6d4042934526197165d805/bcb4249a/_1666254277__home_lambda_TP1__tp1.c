#include <stdio.h>
#include <time.h>
# include <sys/types.h>
# include <unistd.h>

int main(
    
    pid_t idProc;
    
    idProc = fork();
    printf("lol");

}
