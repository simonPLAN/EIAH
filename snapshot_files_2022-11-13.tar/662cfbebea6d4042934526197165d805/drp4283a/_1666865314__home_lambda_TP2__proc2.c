#include <stdio.h>

int main(void){
    execl("p2dils1","test",NULL);
    execvp("p2fils2",27,NULL);
}