int main(char * str){
    printf("chaine transmise: %s \n",); /* chaine transmise */
    printf("nom: %s \n",); /* nom */
    printf("pid: %c \n",getuid()); /* PID */
}