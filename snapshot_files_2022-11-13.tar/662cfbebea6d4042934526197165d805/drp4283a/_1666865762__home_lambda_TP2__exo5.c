int main(){
    
}

int lancerProcess(int nbr){
    for(int i =0; i <= nbr;i++){
        
    }
}

int chercherString(char * str){
    
}