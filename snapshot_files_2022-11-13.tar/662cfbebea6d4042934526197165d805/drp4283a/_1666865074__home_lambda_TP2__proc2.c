int main(void){
    execl("p2dils1","test",);
    execvp();
}