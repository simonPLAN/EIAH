#include <signal.h>

int main(){
    while (true){
        if
    }
}