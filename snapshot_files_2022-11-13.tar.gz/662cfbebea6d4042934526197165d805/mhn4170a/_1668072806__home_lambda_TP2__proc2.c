int main()
{
    execl("./p2fils1.c", "p2fils", "saucisse");
}