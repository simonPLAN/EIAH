#include <stdio.h>
#include <time.h>

printf("%s\n", "abcd");