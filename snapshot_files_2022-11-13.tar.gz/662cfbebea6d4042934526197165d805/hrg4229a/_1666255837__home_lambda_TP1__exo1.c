#include <stdio.h>

char c = 'c';
printf("%c\n", c);