#include <stdio.h>
#include <stdlib.h>

int main(){
    printf("\n****fils1 --> PID = %d\n",getpid());
    exit(3);
}