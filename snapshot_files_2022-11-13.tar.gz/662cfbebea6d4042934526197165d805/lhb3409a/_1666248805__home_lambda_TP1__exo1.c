#include <stdio.h>
#include <time.h>


time_t t;

t=time(NULL);

printf("%s\n",ctime($t));


#include <unistd.h>

uid_t getuid(void);


printf(uid_t);
