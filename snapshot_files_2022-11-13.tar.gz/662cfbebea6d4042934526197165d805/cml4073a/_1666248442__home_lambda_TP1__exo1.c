
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <time.h>

void traitFils1();
void traitFils2();
void traitFils3();

int main () {
    
    
}
