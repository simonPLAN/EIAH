#include <stdio.h>
#include <time.h>
# include <sys/types.h>
# include <unistd.h>

int main(
    
    pid_t fork();
    printf("%d", pid_t);

}
