#include <string.h>
#include <sys/types.h>

void main()
{
  printf("\n***fils1 --> PID= %d\n", getpid());
  
  exit(3);
}