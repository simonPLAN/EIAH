
printf("decinal: %d | hexadecimal: %x \n",,);