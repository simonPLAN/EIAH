#include <stdio.h>

int main(char * str){
    printf("chaine transmise: %s \n",str); /* chaine transmise */
    printf("nom: %s \n",); /* nom */
    printf("pid: %c \n",getuid()); /* PID */
}