int main(int val){
    printf("decinal: %d | hexadecimal: %x \n",val,val);
    return 0;
}