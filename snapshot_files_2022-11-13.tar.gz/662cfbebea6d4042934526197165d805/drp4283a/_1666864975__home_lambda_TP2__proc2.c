int main(void){
    execl();
    execvp();
}